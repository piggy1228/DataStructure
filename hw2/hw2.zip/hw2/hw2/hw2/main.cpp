//
//  main.cpp
//  hw2
//
//  Created by KEXIN ZHU on 9/10/16.
//  Copyright  2016 KEXIN ZHU. All rights reserved.
//

#include <iostream>
#include <vector>
#include <fstream>
#include "Swimmer.h"
#include <sstream>
#include <algorithm>
#include <iomanip>

using namespace std;

bool less_than_event(string &out_string1,string &out_string2){
    return  out_string1 < out_string2;
}

//convert integer to string
string float_to_str(float flt){
    ostringstream temp;
    temp<<flt;
    return temp.str();
}

//print the participants table
void print_the_participants(string &out_string, vector<vector<Swimmer> > &swimmer_in_each_event){
    vector<int> heat_num, semi_num,final_num;
    vector<string> swimmer_first_name,swimmer_last_name, swimmer_country;
    vector<Swimmer> all_swimmers;
    int heats=0,semis=0,finals=0;
    
    //put all the participants together
    for (int i=0; i<swimmer_in_each_event.size(); i++) {
        for (int j=0; j<swimmer_in_each_event[i].size(); j++) {
            all_swimmers.push_back(swimmer_in_each_event[i][j]);
        }
    }
    sort(all_swimmers.begin(),all_swimmers.end(),alphabetical_less_than);

    // count the number of heat, semi and final that each swimmers are in
    int num_of_swimmers=0;
    swimmer_first_name.push_back(all_swimmers[0].first_name());
    swimmer_last_name.push_back(all_swimmers[0].last_name());
    swimmer_country.push_back(all_swimmers[0].country());
    if (all_swimmers[0].round() == "HEAT") {
        heats++;
    }
    else if (all_swimmers[0].round() == "SEMI"){
        semis++;
    }
    else{
        finals++;
    }
    for (int i=1; i<all_swimmers.size(); i++) {
        if (all_swimmers[i].first_name() == swimmer_first_name[num_of_swimmers] && all_swimmers[i].last_name()
            ==swimmer_last_name[num_of_swimmers]) {

            if (all_swimmers[i].round() == "HEAT") {
                heats++;
            }
            else if (all_swimmers[i].round() == "SEMI"){
                semis++;
            }
            else{
                finals++;
            }
        }
        else{
            heat_num.push_back(heats);
            semi_num.push_back(semis);
            final_num.push_back(finals);
            swimmer_first_name.push_back(all_swimmers[i].first_name());
            swimmer_last_name.push_back(all_swimmers[i].last_name());
            swimmer_country.push_back(all_swimmers[i].country());
            if (all_swimmers[i].round() == "HEAT") {
                heats = 1;
                semis = 0;
                finals =0;
            }
            else if (all_swimmers[i].round() == "SEMI"){
                semis = 1;
                heats = 0;
                finals = 0;
            }
            else{
                finals = 1;
                semis = 0;
                heats = 0;
            }
            num_of_swimmers++;

        }
    }
    //for the last person whose round numbers have not be put inside the vectors
    heat_num.push_back(heats);
    semi_num.push_back(semis);
    final_num.push_back(finals);
    
    out_string ="COUNTRY  PARTICIPANT                HEATS  SEMIS  FINALS\n";
    out_string += "--------------------------------------------------------\n";
    
    
    string full_name;
    for(int i=0; i < swimmer_first_name.size();i++){
        out_string += swimmer_country[i];out_string += "      ";
        full_name = swimmer_first_name[i]+" "+swimmer_last_name[i];
        out_string += full_name;
        
        int count_words = int(full_name.size());
        //30 blanks total
        string type_blank(30 - count_words,' ');
        out_string += type_blank;
        string heat_num_str = float_to_str(heat_num[i]);
        string semi_num_str = float_to_str(semi_num[i]);
        string final_num_str = float_to_str(final_num[i]);
        out_string += heat_num_str;
        out_string += "      ";
        out_string += semi_num_str; out_string += "       ";
        out_string += final_num_str;out_string +="\n";

    }

}


//print the event table for relay
void event_table_for_relay(string &out_string,int len,vector<string> &event_type,
                 vector<vector<Swimmer> > &swimmer_in_each_event,int num_of_event){
    string swimmer_name;
    string first_line;
    out_string = event_type[num_of_event];
    string type_blank((40-event_type[num_of_event].size()),' ');
    out_string += type_blank;
    //set width should be 40 blanks
    //print the title of the table
    
    for (int i=0; i<swimmer_in_each_event[num_of_event][0].game_len()/50; i++) {
        int integer = (i+1)*50;
        string int_str = float_to_str(integer);
        first_line += int_str;
        first_line += "m     ";
    }
    first_line+="  FINAL\n";
    string cut_off(first_line.size()+39,'-');
    out_string += first_line;
    out_string += cut_off;out_string+="\n";
    //from the whole table, sort the first 5 swimmers
    sort(swimmer_in_each_event[num_of_event].begin(),swimmer_in_each_event[num_of_event].end(),less_final_time);
    
    //print the 5 swimmers' information
    //38 blanks
    for (int i=0; i<20; i=i+4) {
        cout.setf(ios::left);
        cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        swimmer_name =swimmer_in_each_event[num_of_event][i].relay_team();
        out_string += swimmer_name;
        string type_blank1(int(38-swimmer_name.size()),' ');
        out_string += type_blank1;
        for (int j=0; j<int(swimmer_in_each_event[num_of_event][i].time().size()); j++) {
            string time_string = float_to_str( swimmer_in_each_event[num_of_event][i].time()[j]);
            if (time_string.size()==2) {
                time_string += ".00";
            }
            
            if (time_string.size()==4) {
                time_string += "0";
            }
            out_string += time_string;
            out_string +="    ";
        }
        out_string +=" ";
        out_string += swimmer_in_each_event[num_of_event][i].final_time_str();
        out_string += "\n";

        }

    }


void event_medal_table_for_relay(string &out_string,int len,vector<string> &event_type,
                                 vector<vector<Swimmer> > &swimmer_in_each_event,int num_of_event){
    string swimmer_name;
    string first_line;
    vector<Swimmer> swimmers_in_final;
    vector<Swimmer> first_4_final;
    vector<Swimmer> swimmers_event_medals_table;
    first_4_final.clear();
    swimmers_in_final.clear();
    //sort the final round of the swimmers
    for (int i=0; i< swimmer_in_each_event[num_of_event].size();i++) {
        if (swimmer_in_each_event[num_of_event][i].round() == "FINAL") {
            swimmers_in_final.push_back(swimmer_in_each_event[num_of_event][i]);
        }
    }
    sort(swimmers_in_final.begin(), swimmers_in_final.end(), less_final_time);
    
    //to put the first three swimmers in final and non_medalist in final in a vector
    for (int i=0; i<20; i = i+4) {
        first_4_final.push_back(swimmers_in_final[i]);
    }
    
    //print the title of the table
    // 40blanks
    int count_words =0;
    count_words = int(event_type[num_of_event].size());
    string type_blank(40-count_words,' ');
    out_string = event_type[num_of_event];
    out_string += type_blank;
    
    for (int i=0; i<swimmer_in_each_event[num_of_event][0].game_len()/50; i++) {
        int integer = (i+1)*50;
        string int_str = float_to_str(integer);
        first_line += int_str;
        first_line += "m     ";
    }
    first_line+="  FINAL    MEDALS\n";
    out_string += first_line;
    string cut_off(first_line.size()+39,'-');
    out_string += cut_off;out_string +="\n";
    //from the whole table, sort the first 5 swimmers
    sort(swimmer_in_each_event[num_of_event].begin(),swimmer_in_each_event[num_of_event].end(),less_final_time);
    
    //to merge two top swimmers info together
    for (int i=0; i<5; i++) {
        first_4_final.push_back(swimmer_in_each_event[num_of_event][i]);
    }
    sort(first_4_final.begin(),first_4_final.end(),less_final_time);
    
    swimmers_event_medals_table.push_back(first_4_final[0]);
    int j=0;
    for (int i=1; i<9; i++) {
        if (first_4_final[i].relay_team()!= swimmers_event_medals_table[j].relay_team() || first_4_final[i].round() !=
            swimmers_event_medals_table[j].round()) {
            swimmers_event_medals_table.push_back(first_4_final[i]);
            j++;
        }
    }
    
    
    
    //print the 5 swimmers' information
    //set the width 38
    for (int i=0; i<swimmers_event_medals_table.size(); i++) {
        
        swimmer_name =swimmers_event_medals_table[i].relay_team();
        if (swimmers_event_medals_table[i].round()!="FINAL") {
            swimmer_name += " (";
            swimmer_name += swimmers_event_medals_table[i].round();
            swimmer_name +=")";
            
        }
        
        out_string += swimmer_name;
        //blank 38
        count_words = int(swimmer_name.size());
        string type_blank1(38-count_words,' ');
        out_string += type_blank1;
        
        for (int j=0; j<int(swimmers_event_medals_table[i].time().size()); j++) {
            string time_string = float_to_str(swimmers_event_medals_table[i].time()[j]);
            if (time_string.size()==2) {
                time_string += ".00";
            }
            
            if (time_string.size()==4) {
                time_string += "0";
            }
            out_string += time_string;
            out_string +="    ";
        }
        out_string += swimmers_event_medals_table[i].final_time_str();
        
        //11 blanks
        count_words = int(swimmers_event_medals_table[i].medals().size());
        string type_blank2(11-count_words,' ');
        out_string += type_blank2;
        out_string += swimmers_event_medals_table[i].medals(); out_string +="\n";
    }
}


//to modify the swimmer class, to give them the medals
void set_the_medals(vector<vector<Swimmer> > &swimmers_in_each_event,int num_of_event){
    vector<Swimmer> swimmers_in_final;
    
    //sort the final round of the swimmers
    int j = num_of_event;
        swimmers_in_final.clear();
        for (int i=0; i< swimmers_in_each_event[j].size();i++) {
            if (swimmers_in_each_event[j][i].round() == "FINAL") {
                swimmers_in_final.push_back(swimmers_in_each_event[j][i]);
            }
        }
        sort(swimmers_in_final.begin(), swimmers_in_final.end(), less_final_time);
        
        for (int i=0; i<swimmers_in_each_event[j].size(); i++) {
            if (swimmers_in_final[0].first_name()==swimmers_in_each_event[j][i].first_name() &&
                swimmers_in_final[0].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[0].round()==swimmers_in_each_event[j][i].round()) {
                swimmers_in_each_event[j][i].set_medals("GOLD");
            }
            else if (swimmers_in_final[1].first_name()==swimmers_in_each_event[j][i].first_name() &&
                     swimmers_in_final[1].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[1].round()==swimmers_in_each_event[j][i].round()){
                if (swimmers_in_final[0].final_time() != swimmers_in_final[1].final_time()) {
                    swimmers_in_each_event[j][i].set_medals("SILVER");
                }
                
                else if (swimmers_in_final[0].final_time() == swimmers_in_final[1].final_time()) {
                    swimmers_in_each_event[j][i].set_medals("GOLD");
                }
            }
            else if (swimmers_in_final[2].first_name()==swimmers_in_each_event[j][i].first_name() &&
                     swimmers_in_final[2].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[2].round()==swimmers_in_each_event[j][i].round()){
                if (swimmers_in_final[1].final_time() != swimmers_in_final[2].final_time()) {
                    swimmers_in_each_event[j][i].set_medals("BRONZE");
                }
                else if (swimmers_in_final[1].final_time() == swimmers_in_final[2].final_time()){
                    swimmers_in_each_event[j][i].set_medals("SILVER");
                }
            }
            if (swimmers_in_final[2].final_time()==swimmers_in_final[3].final_time() && swimmers_in_final[2].final_time()!=swimmers_in_final[1].final_time()) {
                if (swimmers_in_final[3].first_name()==swimmers_in_each_event[j][i].first_name() &&
                    swimmers_in_final[3].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[3].round()==swimmers_in_each_event[j][i].round()) {
                    swimmers_in_each_event[j][i].set_medals("BRONZE");
                }
            }
            else if (swimmers_in_final[3].final_time()==swimmers_in_final[4].final_time()) {
                if (swimmers_in_final[4].first_name()==swimmers_in_each_event[j][i].first_name() &&
                    swimmers_in_final[4].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[3].round()==swimmers_in_each_event[j][i].round()) {
                    swimmers_in_each_event[j][i].set_medals("BRONZE");
                }
            }
            
            
           else if (swimmers_in_final[2].final_time()==swimmers_in_final[3].final_time()&& swimmers_in_final[2].final_time()==swimmers_in_final[1].final_time()) {
                if (swimmers_in_final[3].first_name()==swimmers_in_each_event[j][i].first_name() &&
                    swimmers_in_final[3].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[3].round()==swimmers_in_each_event[j][i].round()) {
                    swimmers_in_each_event[j][i].set_medals("SILVER");
                }

            }
        }

}

//set the medals for relay swimmers
//to modify the swimmer class, to give them the medals
void set_the_medals_for_relay(vector<vector<Swimmer> > &swimmers_in_each_event,int num_of_event){
    vector<Swimmer> swimmers_in_final;
    
    //sort the final round of the swimmers
    int j=num_of_event;
        swimmers_in_final.clear();
        for (int i=0; i< swimmers_in_each_event[j].size();i++) {
            if (swimmers_in_each_event[j][i].round() == "FINAL") {
                swimmers_in_final.push_back(swimmers_in_each_event[j][i]);
            }
        }
        sort(swimmers_in_final.begin(), swimmers_in_final.end(), less_final_time);
        
        
        //find the person who win the medals and set medals in the vector
        for (int i=0; i<swimmers_in_each_event[j].size(); i++) {
            for (int k=0; k<4; k++) {
                if (swimmers_in_final[k].first_name()==swimmers_in_each_event[j][i].first_name() &&
                    swimmers_in_final[k].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[k].round()==swimmers_in_each_event[j][i].round()) {
                    swimmers_in_each_event[j][i].set_medals("GOLD");

                                }
            }
            for (int k=4; k<8; k++) {
                if (swimmers_in_final[k].first_name()==swimmers_in_each_event[j][i].first_name() &&
                         swimmers_in_final[k].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[k].round()==swimmers_in_each_event[j][i].round()){
                    if (swimmers_in_final[0].final_time() != swimmers_in_final[4].final_time()) {
                        swimmers_in_each_event[j][i].set_medals("SILVER");
                       
                    }
                    
                    else if (swimmers_in_final[0].final_time() == swimmers_in_final[4].final_time()) {
                        swimmers_in_each_event[j][i].set_medals("GOLD");
                    }
                }

            }
            
            for (int k=8; k<12; k++) {
                if (swimmers_in_final[k].first_name()==swimmers_in_each_event[j][i].first_name() &&
                         swimmers_in_final[k].last_name()==swimmers_in_each_event[j][i].last_name()&&swimmers_in_final[k].round()==swimmers_in_each_event[j][i].round()){
                    if (swimmers_in_final[4].final_time() != swimmers_in_final[8].final_time()) {
                        swimmers_in_each_event[j][i].set_medals("BRONZE");
                        
                    }
                    else if (swimmers_in_final[4].final_time() == swimmers_in_final[8].final_time()){
                        swimmers_in_each_event[j][i].set_medals("SILVER");
                       
                    }
                }

            }
        }
    }








//convert the string time to float with second unit
float time_str_to_float(string s){
    string letter;
    string minute="";
    string second="";
    int min=0;
    float sec=0;
    for (int i=0; i<int(s.size()); i++) {
        letter = s[i];
        if (letter == ":") {
            min = atoi(minute.c_str());
            for (int j=i+1; j<s.size(); j++) {
                second+=s[j];
            }
            sec = atof(second.c_str());
            break;
        }
        else{
            minute += letter;
        }

    }
    return min*60+sec;
}




//print the event table
void event_table(string &out_string,int len,vector<string> &event_type,
    vector<vector<Swimmer> > &swimmer_in_each_event,int num_of_event){
    string swimmer_name;
    string first_line;
    int count_words = 0;
    
    
    out_string = event_type[num_of_event];
    count_words = int(event_type[num_of_event].size());
    string type_blank0(40-count_words,' ');
    //set width should be 40 blanks
    out_string += type_blank0;
    //print the title of the table

    for (int i=0; i<swimmer_in_each_event[num_of_event][0].game_len()/50; i++) {
        int integer = (i+1)*50;
        string int_str = float_to_str(integer);
        first_line += int_str;
        first_line += "m     ";
    }
    first_line+="  FINAL\n";
    const string cut_off(first_line.size()+39,'-');
    out_string += first_line;
    out_string +=cut_off;
    out_string+="\n";
    //from the whole table, sort the first 5 swimmers
    sort(swimmer_in_each_event[num_of_event].begin(),swimmer_in_each_event[num_of_event].end(),less_final_time);
    
    //print the 5 swimmers' information
    //38 blanks
    for (int i=0; i<5; i++) {
        cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        swimmer_name =swimmer_in_each_event[num_of_event][i].first_name()+" "+swimmer_in_each_event[num_of_event][i].last_name();
        out_string += swimmer_name;
        count_words = int(swimmer_name.size());
        const string type_blank(38-count_words,' ');
        out_string += type_blank;
                          
        for (int j=0; j<int(swimmer_in_each_event[num_of_event][i].time().size()); j++) {
            string time_string = float_to_str( swimmer_in_each_event[num_of_event][i].time()[j]);
            if (time_string.size()==2) {
                time_string += ".00";
            }
            
            if (time_string.size()==4) {
                time_string += "0";
            }
            out_string += time_string;
            out_string +="    ";
        }

        out_string +=" ";
       out_string += swimmer_in_each_event[num_of_event][i].final_time_str();
        out_string += "\n";
    }
}


//print events with medals
void event_medal_table(string &out_string,int len,vector<string> &event_type,
        vector<vector<Swimmer> > &swimmer_in_each_event,int num_of_event){
    string swimmer_name;
    string first_line;
    vector<Swimmer> swimmers_in_final;
    vector<Swimmer> first_4_final;
    vector<Swimmer> swimmers_event_medals_table;
    first_4_final.clear();
    swimmers_in_final.clear();
    //sort the final round of the swimmers
    for (int i=0; i< swimmer_in_each_event[num_of_event].size();i++) {
        if (swimmer_in_each_event[num_of_event][i].round() == "FINAL") {
            swimmers_in_final.push_back(swimmer_in_each_event[num_of_event][i]);
        }
    }
    sort(swimmers_in_final.begin(), swimmers_in_final.end(), less_final_time);
    
    //to put the first three swimmers in final and non_medalist in final in a vector
    for (int i=0; i<4; i++) {
        first_4_final.push_back(swimmers_in_final[i]);
    }

    //print the title of the table
    //totally 40 position
    out_string = event_type[num_of_event];
    int count_words = int(event_type[num_of_event].size());
    string type_blank(40-count_words,' ');
    out_string += type_blank;
    
    for (int i=0; i<swimmer_in_each_event[num_of_event][0].game_len()/50; i++) {
        int integer = (i+1)*50;
        string int_str = float_to_str(integer);
        first_line += int_str;
        first_line += "m     ";
    }
    first_line+="  FINAL    MEDALS";
    string cut_off(first_line.size()+40,'-');
    out_string += first_line; out_string += "\n";
    out_string += cut_off; out_string += "\n";
    //from the whole table, sort the first 5 swimmers
    sort(swimmer_in_each_event[num_of_event].begin(),swimmer_in_each_event[num_of_event].end(),less_final_time);
    
    //to merge two top swimmers info together
    for (int i=0; i<5; i++) {
        first_4_final.push_back(swimmer_in_each_event[num_of_event][i]);
        }
    sort(first_4_final.begin(),first_4_final.end(),less_final_time);
    
    swimmers_event_medals_table.push_back(first_4_final[0]);
    int j=0;
    for (int i=1; i<9; i++) {
        if (first_4_final[i].first_name()!= swimmers_event_medals_table[j].first_name() || first_4_final[i].last_name() !=
            swimmers_event_medals_table[j].last_name() || first_4_final[i].round() !=
            swimmers_event_medals_table[j].round()) {
            swimmers_event_medals_table.push_back(first_4_final[i]);
            j++;
        }
    }

    
    
    //print the 5 swimmers' information
    //set the width 38
    for (int i=0; i<swimmers_event_medals_table.size(); i++) {

        swimmer_name =swimmers_event_medals_table[i].first_name()+" "+swimmers_event_medals_table[i].last_name();
        if (swimmers_event_medals_table[i].round()!="FINAL") {
            swimmer_name += " (";
            swimmer_name += swimmers_event_medals_table[i].round();
            swimmer_name +=")";

        }
        out_string += swimmer_name;
        count_words = int(swimmer_name.size());
        string type_blank1(38-count_words,' ');
        out_string += type_blank1;
        for (int j=0; j<int(swimmers_event_medals_table[i].time().size()); j++) {
            string time_string = float_to_str( swimmers_event_medals_table[i].time()[j]);
            if (time_string.size()==2) {
                time_string += ".00";
            }
            
            if (time_string.size()==4) {
                time_string += "0";
            }
            out_string += time_string;
            out_string +="    ";

        }
        out_string += swimmers_event_medals_table[i].final_time_str();
        count_words =int(swimmers_event_medals_table[i].medals().size());
        string type_blank2(11-count_words,' ');
        out_string+=type_blank2;
        out_string += swimmers_event_medals_table[i].medals();out_string+="\n";

    }
}


//print the participants with medals table
void print_the_participants_medals(string &out_string, vector<vector<Swimmer> > &swimmer_in_each_event){
    vector<int> heat_num, semi_num,final_num, gold_num ,silver_num, bronze_num;
    vector<string> swimmer_first_name,swimmer_last_name, swimmer_country;
    vector<Swimmer> all_swimmers;
    int heats=0,semis=0,finals=0,golds = 0, silvers = 0,bronze = 0;
    //put all the participants together
    for (int i=0; i<swimmer_in_each_event.size(); i++) {
        for (int j=0; j<swimmer_in_each_event[i].size(); j++) {
            all_swimmers.push_back(swimmer_in_each_event[i][j]);
        }
    }
    sort(all_swimmers.begin(),all_swimmers.end(),alphabetical_less_than);
    
    // count the number of heat, semi and final that each swimmers are in
    int num_of_swimmers=0;
    swimmer_first_name.push_back(all_swimmers[0].first_name());
    swimmer_last_name.push_back(all_swimmers[0].last_name());
    swimmer_country.push_back(all_swimmers[0].country());
    if (all_swimmers[0].round() == "HEAT") {
        heats++;
    }
    else if (all_swimmers[0].round() == "SEMI"){
        semis++;
    }
    else{
        finals++;
        if (all_swimmers[0].medals() == "GOLD") {
            golds++;
        }
        else if(all_swimmers[0].medals() == "SILVER"){
            silvers++;
        }
        else if (all_swimmers[0].medals() == "BRONZE"){
            bronze++;
        }
    }
    for (int i=1; i<all_swimmers.size(); i++) {
        if (all_swimmers[i].first_name() == swimmer_first_name[num_of_swimmers] && all_swimmers[i].last_name()
            ==swimmer_last_name[num_of_swimmers]) {
            
            if (all_swimmers[i].round() == "HEAT") {
                heats++;
            }
            else if (all_swimmers[i].round() == "SEMI"){
                semis++;
            }
            else{
                finals++;
                if (all_swimmers[i].medals() == "GOLD") {
                    golds++;
                }
                else if(all_swimmers[i].medals() == "SILVER"){
                    silvers++;
                }
                else if (all_swimmers[i].medals() == "BRONZE"){
                    bronze++;
                    
                }
                /*else{
                    golds = 0;
                    silvers = 0;
                    bronze = 0;
                }*/
                
            }
        }
        else{
            heat_num.push_back(heats);
            semi_num.push_back(semis);
            final_num.push_back(finals);
            gold_num.push_back(golds);
            silver_num.push_back(silvers);
            bronze_num.push_back(bronze);
            swimmer_first_name.push_back(all_swimmers[i].first_name());
            swimmer_last_name.push_back(all_swimmers[i].last_name());
            swimmer_country.push_back(all_swimmers[i].country());
            if (all_swimmers[i].round() == "HEAT") {
                heats = 1;
                semis = 0;
                finals =0;
                golds = 0;
                silvers = 0;
                bronze = 0;
            }
            else if (all_swimmers[i].round() == "SEMI"){
                semis = 1;
                heats = 0;
                finals = 0;
                golds = 0;
                silvers = 0;
                bronze = 0;
            }
            else{
                finals = 1;
                semis = 0;
                heats = 0;
                if (all_swimmers[i].medals() == "GOLD") {
                    golds = 1;
                    silvers = 0;
                    bronze = 0;
                }
                else if(all_swimmers[i].medals() == "SILVER"){
                    golds = 0;
                    silvers = 1;
                    bronze = 0;
                }
                else if (all_swimmers[i].medals() == "BRONZE"){
                    golds = 0;
                    silvers = 0;
                    bronze = 1;
                    
                }
                else{
                    bronze = 0;
                    silvers = 0;
                    golds = 0;
                }
                
            }
            num_of_swimmers++;
            i--;
            golds =0;
            silvers = 0;
            bronze = 0;
            
        }
    }
    //for the last person whose round numbers have not be put inside the vectors
    heat_num.push_back(heats);
    semi_num.push_back(semis);
    final_num.push_back(finals);
    gold_num.push_back(golds);
    silver_num.push_back(silvers);
    bronze_num.push_back(bronze);
    
    out_string = "COUNTRY  PARTICIPANT                HEATS  SEMIS  FINALS    GOLD  SILVER  BRONZE\n";
    out_string += "--------------------------------------------------------------------------------\n";
    
    
    string full_name;
    for(int i=0; i < swimmer_first_name.size();i++){
        out_string += swimmer_country[i]; out_string += "      ";
        full_name = swimmer_first_name[i]+" "+swimmer_last_name[i];
        int count_words=int(full_name.size());
        out_string += full_name;
        //blank and full name,totally 30 size
        string type_blank(30 - count_words,' ');
        out_string += type_blank;
        
        if (heat_num[i]==0) {
            out_string+=" ";
        }
        else{
            string heat_num_str = float_to_str(heat_num[i]);
            
            out_string += heat_num_str;}
            out_string += "      ";
        
        
        if (semi_num[i]==0) {
            out_string += " ";
        }
        else{
            string semi_num_str = float_to_str(semi_num[i]);
            out_string += semi_num_str; }
            out_string += "       ";
        
        if (final_num[i]==0) {
            out_string += " ";
        }
        else{
            string final_num_str = float_to_str(final_num[i]);
            out_string += final_num_str;} out_string += "       ";
        
        if (gold_num[i]  == 0) {
            out_string += "        ";
        }
        else{
            string gold_num_str = float_to_str(gold_num[i]);
            out_string += gold_num_str; out_string += "       ";
        }
        if (silver_num[i] == 0) {
            out_string += "        ";
        }
        else{
            string silver_num_str = float_to_str(silver_num[i]);
            out_string += silver_num_str; out_string += "       ";
        }
        if (bronze_num[i]==0) {
            out_string+="\n";
        }
        else{
            string bronze_num_str = float_to_str(bronze_num[i]);
            out_string += bronze_num_str; out_string += "\n";
        }
    }
    
}



int main(int argc, const char * argv[]) {
    string event,title,word,gender,length,type;
    string round,number,lane_number,first_name,last_name, country,final_time_str,
    relay_team;
    float sec=0,sec0=0,sec1=0;
    vector<float> time;
    float float_final_time = 0,final_time= 0;
    vector<string> event_type;
    int len=0,game_len=0;
    vector<vector<Swimmer> > swimmers_in_each_event;
    vector<Swimmer> swimmers_in_one_event;
    Swimmer one_swimmer;
    string out_string;
    bool isRelay = false;
    
    //use the argument to get the info
    ifstream in_str(argv[1]);
    ofstream out_str(argv[2]);
    string basic_type(argv[3]);
    string extended_type = "";
    if (argc == 5) {
        extended_type = "MEDALS";
      
    }
    
    
    if (!in_str.good()) {
        cerr << "Can't open " << argv[1] << " to read.\n";
        exit(1);
    }
    if (!out_str.good()) {
        cerr << "Can't open " << argv[2] << " to write.\n";
        exit(1);
    }
    if (argc != 4 && argc!=5) {
        cerr << "wrong number of argument.\n";
    }

  
    if (basic_type != "events" && basic_type != "participants" && basic_type !=
        "custom") {
        cerr << "Invalid input.\n";
        exit(1);
    }
    
    
    //begin to read input data
    while (in_str >> word) {
        if (word == "EVENT") {
            isRelay = false;
            if (swimmers_in_one_event.size()>0) {
                //put all the swimmers in the same event in one vector
                swimmers_in_each_event.push_back(swimmers_in_one_event);
                swimmers_in_one_event.clear();

            }
            in_str >> gender >> length >> type;
            // TODO write to competition info
            if (length[1]=='x') {
                string firstNumber = length.substr(0, 1);
                string secondNumber = length.substr(2, length.size() - 1);
                int multi = atoi(firstNumber.c_str());
                int multi2 = atoi(secondNumber.c_str());
                len = multi * multi2;
                game_len = len;
            }
            else{
                //to calculate the numbers of laps
            len = atoi(length.c_str());
            game_len = len;
                
            }
            event = gender + " " + length +" "+type;
            //to create the event vector, to count the event number and types
            event_type.push_back(event);
        }
        else if (word == "HEAT" || word == "SEMI" || word == "FINAL")
        {
            if (isRelay){
                round = word;
                if (word == "FINAL") {
                    number = "0";
                    in_str >> lane_number >> relay_team>>country;
                }
                else{
                    in_str >> number >> lane_number >> relay_team >>country;
                }
                time.clear();
                for (int i=0; i < len/50; i++) {
                    in_str >> word;
                    if (word.size()==5) {
                        sec1 = atof(word.c_str());
                    }
                    else{
                        sec1 = time_str_to_float(word);
                    }
                    sec = sec1-sec0;
                    sec0 = sec1;
                    float_final_time += sec;
                    time.push_back(sec);
                    final_time_str = word;
                }
                
                final_time = float_final_time;
                sec0 = 0;
                float_final_time = 0;
                string medals="";
                for (int k=0; k<4; k++) {
                    in_str>>first_name >> last_name;
                    Swimmer one_swimmer(first_name, last_name,round, number,lane_number,country,time, event,final_time,game_len,final_time_str,medals,relay_team);
                    swimmers_in_one_event.push_back(one_swimmer);
                }
            }
            else {
            // TODO read swimmer info from in_str
            round = word;
            if (word == "FINAL") {
                number = "0";
                in_str >> lane_number >> first_name >> last_name >> country;
            }
            else{
                in_str>> number >> lane_number >> first_name >> last_name >> country;
            }
            //put all the time into the time vector.First to calculate each 50m lap
            //then put the final time in it.
            time.clear();
            for (int i=0; i < len/50; i++) {
                in_str >> word;
                if (word.size()==5) {
                    sec1 = atof(word.c_str());
                }
                else{
                    sec1 = time_str_to_float(word);
                }
                sec = sec1-sec0;
                sec0 = sec1;
                float_final_time += sec;
                time.push_back(sec);
                final_time_str = word;
            }
            
            final_time = float_final_time;
            sec0 = 0;
            float_final_time = 0;
            string medals="";
            string relay_team="";
            // TODO construct swimmer info
            Swimmer one_swimmer (first_name, last_name,round, number,lane_number,country,time, event,final_time,game_len,final_time_str,medals,relay_team);
            swimmers_in_one_event.push_back(one_swimmer);}
        }
        else if (word=="Relay"){
            isRelay = true;
            event +=" Relay";
            event_type.pop_back();
            event_type.push_back(event);
        }
        
    
        // when the competition has 4th argument
        else
        {
            isRelay = false;
            // TODO competition info add extra detail
            event+=" ";
            event += word;
            //to delete the wrong event name and change it to the new event name
            event_type.pop_back();
            event_type.push_back(event);
        }
        
    }
    swimmers_in_each_event.push_back(swimmers_in_one_event);
    // finish to arrange the input data.
    // begin to call for the output data
  
    vector<string> ordered_event_table;
    vector<string> ordered_event_medal_table;
    //output the data into the output txt
    for (int num_of_event=0; num_of_event<int(event_type.size()); num_of_event++) {
        if (swimmers_in_each_event[num_of_event][0].relay_team() =="") {
            set_the_medals(swimmers_in_each_event,num_of_event);
            event_table(out_string, len,event_type,swimmers_in_each_event,num_of_event);
            ordered_event_table.push_back(out_string);
            event_medal_table(out_string, len,event_type, swimmers_in_each_event,num_of_event);
            ordered_event_medal_table.push_back(out_string);

        }
        
        else{
            set_the_medals_for_relay(swimmers_in_each_event,num_of_event);
            
            event_table_for_relay(out_string, len, event_type, swimmers_in_each_event, num_of_event);
            ordered_event_table.push_back(out_string);
            event_medal_table_for_relay(out_string, len, event_type, swimmers_in_each_event, num_of_event);

            ordered_event_medal_table.push_back(out_string);
        }
            }
    
    if (basic_type == "events" && extended_type =="") {
        sort(ordered_event_table.begin(), ordered_event_table.end(), less_than_event);
        for (int i=0; i<ordered_event_table.size(); i++) {
            out_str << ordered_event_table[i];
            out_str << "\n";
        }
    }
    
    else if (basic_type == "events" && extended_type == "MEDALS") {
        sort(ordered_event_medal_table.begin(),ordered_event_medal_table.end(),less_than_event);
        for (int i=0 ; i<ordered_event_medal_table.size(); i++) {
            out_str << ordered_event_medal_table[i];
            out_str << "\n";
        }

    }
    
    
    else if (basic_type == "participants" && extended_type == "") {
        print_the_participants(out_string, swimmers_in_each_event);
        out_str << out_string;
    }
    
    else if (basic_type == "participants" && extended_type == "MEDALS"){
        print_the_participants_medals(out_string, swimmers_in_each_event);
        out_str << out_string;
    }
    
    return 0;
}
