HOMEWORK 4: DEBUGGING

NAME:  Kexin Zhu


ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  20h


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(TAs, ALAC tutors, upperclassmen, students/instructor via LMS,
etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: All finding and fixing bugs for this assignment must be done
on your own, as described in "Academic Integrity for Homework"
handout.  You may not discuss the bugs in this assignment with other
students in the course.



MISC. COMMENTS TO GRADER:
I am poor at English, so maybe my language will be a little bit confusing in the report. I feel bad about that.
